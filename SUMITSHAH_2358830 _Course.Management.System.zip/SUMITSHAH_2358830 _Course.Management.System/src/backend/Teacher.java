package backend;

public class Teacher {

}
