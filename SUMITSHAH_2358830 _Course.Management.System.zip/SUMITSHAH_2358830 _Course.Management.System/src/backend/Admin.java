package backend;

public class Admin extends User {
	
	
	public Admin() {
		
	}

	Adnin sc  new Admin();
}
